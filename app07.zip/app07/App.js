import { View } from 'react-native';
import Anuncios from './src/pages/Anuncios/index'


export default function App() {
  return (
    <View>
     <Anuncios />
    </View>
  );
}
