import { View } from 'react-native';
import Vagas from './src/pages/Vagas/index'

export default function App() {
  return (
    <View >
      <Vagas />
    </View>
  );
}
