import { View } from 'react-native';

import Multiplicador from './src/pages/Multiplicador/index';

export default function App() {
  return (
    <View >
      <Multiplicador />
    </View>
  );
}


