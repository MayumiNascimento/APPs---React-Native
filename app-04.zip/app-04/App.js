import { View } from 'react-native';
import AlcoolGasolina from './src/pages/AlcoolGasolina/index';

export default function App() {
  return (
    <View>
      <AlcoolGasolina />
    </View>
  );
}
