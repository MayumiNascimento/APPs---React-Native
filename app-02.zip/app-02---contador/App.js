import { View, Text } from 'react-native'
import Contador from './src/pages/Contador'

function App(){
  return(
    <View>
      <Contador />
    </View>
  )
}

export default App