import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  separador:{
    marginTop: 15,
    marginStart: 15,
    marginEnd: 15
  }
})

export {styles}