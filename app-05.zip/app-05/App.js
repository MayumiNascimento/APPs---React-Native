import { View } from 'react-native';
import IMC from './src/pages/IMC/index'

export default function App() {
  return (
    <View>
      <IMC />
    </View>
  );
}

