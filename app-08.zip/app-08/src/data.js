export const data = [
  {
    id: 1,
    titulo: 'Desenvolvedor Backend',
    salario: 'R$ 3000,00',
    descricao: 'Desenvolvimento de APIs em Node.js',
    contato: 'backend@empresa.com',
  },
  {
    id: 2,
    titulo: 'Engenheiro de Dados',
    salario: 'R$ 3000,00',
    descricao: 'Processamento de grandes volumes de dados',
    contato: 'dados@empresa.com',
  },
  {
    id: 3,
    titulo: 'UI/UX Designer',
    salario: 'R$ 2500,00',
    descricao: 'Design de interfaces mobile',
    contato: 'designer@empresa.com',
  },
  {
    id: 4,
    titulo: 'Analista de QA Jr',
    salario: 'R$ 2700,00',
    descricao: 'Testes automatizados e manuais',
    contato: 'qa@empresa.com',
  },
  {
    id: 5,
    titulo: 'Analista de QA Pleno',
    salario: 'R$ 4000,00',
    descricao: 'Testes automatizados e manuais',
    contato: 'qa@empresa.com',
  },
  {
    id: 6,
    titulo: 'Desenvolvedor Java',
    salario: 'R$ 7000,00',
    descricao: 'Programação em Java',
    contato: 'dev@empresa.com',
  },
];
