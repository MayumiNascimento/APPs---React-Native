import { View } from 'react-native';
import NumeroAleatorio from './src/pages/NumeroAleatorio/index'

export default function App() {
  return (
    <View>
      <NumeroAleatorio />
    </View>
  );
}

