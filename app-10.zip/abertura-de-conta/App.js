import { View } from 'react-native';
import Form from './src/pages/Form/index'

function App() {
  return(
    <View>
      <Form />
    </View>
  )
}

export default App