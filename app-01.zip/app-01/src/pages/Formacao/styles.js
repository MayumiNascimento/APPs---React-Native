import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({

    content:{
        marginTop: '1%'
    },

    titulo:{
        fontSize: 15,
        fontWeight: 'bold',
    },

    descricao:{
      fontSize: 15,
      color: '#0000ff'
    },
   
});
export {styles}